<?php
/**
 * GitHub API class for WP Puller.
 *
 * @package WP_Puller
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * WP_Puller_GitHub_API Class.
 */
class WP_Puller_GitHub_API {

    /**
     * GitHub API base URL.
     *
     * @var string
     */
    const API_BASE = 'https://api.github.com';

    /**
     * GitHub raw content base URL.
     *
     * @var string
     */
    const RAW_BASE = 'https://raw.githubusercontent.com';

    /**
     * Cache transient prefix.
     *
     * @var string
     */
    const CACHE_PREFIX = 'wp_puller_cache_';

    /**
     * Cache duration in seconds (5 minutes).
     *
     * @var int
     */
    const CACHE_DURATION = 300;

    /**
     * Optional PAT for per-asset authentication.
     *
     * @var string|null
     */
    private $pat = null;

    /**
     * Constructor.
     *
     * @param string|null $pat Optional Personal Access Token for this API instance.
     */
    public function __construct( $pat = null ) {
        $this->pat = $pat;
    }

    /**
     * Parse a GitHub repository URL.
     *
     * Supports formats:
     * - https://github.com/owner/repo
     * - https://github.com/owner/repo.git
     * - git@github.com:owner/repo.git
     * - owner/repo
     *
     * @param string $url Repository URL or owner/repo.
     * @return array|false Array with 'owner' and 'repo' keys, or false on failure.
     */
    public function parse_repo_url( $url ) {
        $url = trim( $url );

        if ( empty( $url ) ) {
            return false;
        }

        // Match owner/repo format
        if ( preg_match( '/^([a-zA-Z0-9_-]+)\/([a-zA-Z0-9_.-]+)$/', $url, $matches ) ) {
            return array(
                'owner' => $matches[1],
                'repo'  => $this->strip_git_suffix( $matches[2] ),
            );
        }

        // Match github.com URLs
        if ( preg_match( '/github\.com[\/:]([a-zA-Z0-9_-]+)\/([a-zA-Z0-9_.-]+)/', $url, $matches ) ) {
            return array(
                'owner' => $matches[1],
                'repo'  => $this->strip_git_suffix( $matches[2] ),
            );
        }

        return false;
    }

    /**
     * Remove .git suffix from repo name if present.
     *
     * @param string $repo Repository name.
     * @return string
     */
    private function strip_git_suffix( $repo ) {
        if ( substr( $repo, -4 ) === '.git' ) {
            return substr( $repo, 0, -4 );
        }
        return $repo;
    }

    /**
     * Get repository information.
     *
     * @param string $owner Repository owner.
     * @param string $repo  Repository name.
     * @return array|WP_Error
     */
    public function get_repo_info( $owner, $repo ) {
        $cache_key = self::CACHE_PREFIX . 'repo_' . md5( $owner . $repo );
        $cached    = get_transient( $cache_key );

        if ( false !== $cached ) {
            return $cached;
        }

        $response = $this->api_request( "/repos/{$owner}/{$repo}" );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        set_transient( $cache_key, $response, self::CACHE_DURATION );

        return $response;
    }

    /**
     * Get the latest commit on a branch.
     *
     * @param string $owner  Repository owner.
     * @param string $repo   Repository name.
     * @param string $branch Branch name.
     * @return array|WP_Error
     */
    public function get_latest_commit( $owner, $repo, $branch = 'main' ) {
        $cache_key = self::CACHE_PREFIX . 'commit_' . md5( $owner . $repo . $branch );
        $cached    = get_transient( $cache_key );

        if ( false !== $cached ) {
            return $cached;
        }

        $response = $this->api_request( "/repos/{$owner}/{$repo}/commits/{$branch}" );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $commit_data = array(
            'sha'       => $response['sha'],
            'message'   => isset( $response['commit']['message'] ) ? $response['commit']['message'] : '',
            'author'    => isset( $response['commit']['author']['name'] ) ? $response['commit']['author']['name'] : '',
            'date'      => isset( $response['commit']['author']['date'] ) ? $response['commit']['author']['date'] : '',
            'short_sha' => substr( $response['sha'], 0, 7 ),
        );

        set_transient( $cache_key, $commit_data, self::CACHE_DURATION );

        return $commit_data;
    }

    /**
     * Get raw file content from a repository.
     *
     * @param string $owner  Repository owner.
     * @param string $repo   Repository name.
     * @param string $branch Branch name.
     * @param string $path   File path within the repository.
     * @return string|WP_Error File content or error.
     */
    public function get_raw_file( $owner, $repo, $branch, $path ) {
        $url = sprintf(
            '%s/%s/%s/%s/%s',
            self::RAW_BASE,
            rawurlencode( $owner ),
            rawurlencode( $repo ),
            rawurlencode( $branch ),
            $path
        );

        $args = array(
            'timeout'   => 15,
            'sslverify' => true,
            'headers'   => array(
                'User-Agent' => 'WP-Puller/' . WP_PULLER_VERSION,
            ),
        );

        $auth_header = $this->get_auth_header();
        if ( ! empty( $auth_header ) ) {
            $args['headers']['Authorization'] = $auth_header;
        }

        $response = wp_remote_get( $url, $args );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        if ( 200 !== wp_remote_retrieve_response_code( $response ) ) {
            return new WP_Error( 'file_not_found', 'Could not fetch file from repository.' );
        }

        return wp_remote_retrieve_body( $response );
    }

    /**
     * Download repository archive as ZIP.
     *
     * @param string $owner  Repository owner.
     * @param string $repo   Repository name.
     * @param string $branch Branch name.
     * @return string|WP_Error Path to downloaded ZIP file, or error.
     */
    public function download_archive( $owner, $repo, $branch = 'main' ) {
        // Use GitHub API endpoint for downloading archives (works better with auth)
        $url = sprintf(
            'https://api.github.com/repos/%s/%s/zipball/%s',
            rawurlencode( $owner ),
            rawurlencode( $repo ),
            rawurlencode( $branch )
        );

        $args = array(
            'timeout'   => 120,
            'sslverify' => true,
            'headers'   => array(
                'Accept'     => 'application/vnd.github+json',
                'User-Agent' => 'WP-Puller/' . WP_PULLER_VERSION,
            ),
        );

        $auth_header = $this->get_auth_header();
        if ( ! empty( $auth_header ) ) {
            $args['headers']['Authorization'] = $auth_header;
        }

        $tmp_file = wp_tempnam( 'wp-puller-' );
        $response = wp_remote_get( $url, $args );

        if ( is_wp_error( $response ) ) {
            @unlink( $tmp_file );
            return $response;
        }

        $status_code = wp_remote_retrieve_response_code( $response );

        if ( 200 !== $status_code ) {
            @unlink( $tmp_file );

            if ( 404 === $status_code ) {
                return new WP_Error(
                    'repo_not_found',
                    __( 'Repository or branch not found. Check URL and branch name.', 'wp-puller' )
                );
            }

            if ( 401 === $status_code || 403 === $status_code ) {
                return new WP_Error(
                    'auth_failed',
                    __( 'Authentication failed. Check your Personal Access Token.', 'wp-puller' )
                );
            }

            return new WP_Error(
                'download_failed',
                sprintf(
                    /* translators: %d: HTTP status code */
                    __( 'Failed to download repository. HTTP status: %d', 'wp-puller' ),
                    $status_code
                )
            );
        }

        $body = wp_remote_retrieve_body( $response );

        global $wp_filesystem;
        if ( ! $wp_filesystem ) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
            WP_Filesystem();
        }

        if ( ! $wp_filesystem->put_contents( $tmp_file, $body ) ) {
            @unlink( $tmp_file );
            return new WP_Error(
                'write_failed',
                __( 'Failed to save downloaded file.', 'wp-puller' )
            );
        }

        return $tmp_file;
    }

    /**
     * Test connection to repository.
     *
     * @param string $repo_url Repository URL.
     * @return array|WP_Error Repository info on success, error on failure.
     */
    public function test_connection( $repo_url ) {
        $parsed = $this->parse_repo_url( $repo_url );

        if ( ! $parsed ) {
            return new WP_Error(
                'invalid_url',
                __( 'Invalid GitHub repository URL.', 'wp-puller' )
            );
        }

        return $this->get_repo_info( $parsed['owner'], $parsed['repo'] );
    }

    /**
     * Make an API request to GitHub.
     *
     * @param string $endpoint API endpoint.
     * @param array  $args     Request arguments.
     * @return array|WP_Error
     */
    private function api_request( $endpoint, $args = array() ) {
        $url = self::API_BASE . $endpoint;

        $default_args = array(
            'timeout'   => 30,
            'sslverify' => true,
            'headers'   => array(
                'Accept'     => 'application/vnd.github+json',
                'User-Agent' => 'WP-Puller/' . WP_PULLER_VERSION,
                'X-GitHub-Api-Version' => '2022-11-28',
            ),
        );

        $auth_header = $this->get_auth_header();
        if ( ! empty( $auth_header ) ) {
            $default_args['headers']['Authorization'] = $auth_header;
        }

        $args     = wp_parse_args( $args, $default_args );
        $response = wp_safe_remote_get( $url, $args );

        // Debug logging
        if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
            error_log( 'WP Puller API Request: ' . $url );
            error_log( 'WP Puller Auth Header: ' . ( ! empty( $auth_header ) ? substr( $auth_header, 0, 20 ) . '...' : 'none' ) );
            error_log( 'WP Puller Response Code: ' . wp_remote_retrieve_response_code( $response ) );
        }

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $status_code = wp_remote_retrieve_response_code( $response );
        $body        = wp_remote_retrieve_body( $response );
        $data        = json_decode( $body, true );

        if ( 200 !== $status_code && 201 !== $status_code ) {
            $message = isset( $data['message'] ) ? $data['message'] : __( 'Unknown error', 'wp-puller' );
            $doc_url = isset( $data['documentation_url'] ) ? $data['documentation_url'] : '';

            if ( 401 === $status_code ) {
                return new WP_Error(
                    'auth_error',
                    __( 'GitHub authentication failed (401). Your token may be invalid or expired.', 'wp-puller' )
                );
            }

            if ( 403 === $status_code ) {
                if ( strpos( $message, 'rate limit' ) !== false ) {
                    return new WP_Error(
                        'rate_limited',
                        __( 'GitHub API rate limit exceeded. Try again later or add a Personal Access Token.', 'wp-puller' )
                    );
                }
                return new WP_Error(
                    'forbidden',
                    sprintf(
                        /* translators: %s: GitHub error message */
                        __( 'Access forbidden (403): %s', 'wp-puller' ),
                        $message
                    )
                );
            }

            if ( 404 === $status_code ) {
                $pat = $this->get_pat();
                $has_pat = ! empty( $pat );
                $auth_type = '';

                if ( $has_pat ) {
                    if ( strpos( $pat, 'github_pat_' ) === 0 ) {
                        $auth_type = 'fine-grained';
                    } elseif ( strpos( $pat, 'ghp_' ) === 0 ) {
                        $auth_type = 'classic';
                    } else {
                        $auth_type = 'unknown-format';
                    }
                }

                if ( ! $has_pat ) {
                    return new WP_Error(
                        'not_found',
                        __( 'Repository not found (404). For private repos, add a Personal Access Token.', 'wp-puller' )
                    );
                }

                return new WP_Error(
                    'not_found',
                    sprintf(
                        /* translators: %1$s: auth type, %2$s: endpoint */
                        __( 'Repository not found (404). Auth: %1$s. Endpoint: %2$s. Ensure token has Contents + Metadata read access for this specific repo.', 'wp-puller' ),
                        $auth_type,
                        $endpoint
                    )
                );
            }

            return new WP_Error( 'api_error', sprintf( 'GitHub API error (%d): %s', $status_code, $message ) );
        }

        return $data;
    }

    /**
     * Get the Personal Access Token.
     *
     * Returns the PAT passed to the constructor if set, otherwise empty string.
     *
     * @return string
     */
    private function get_pat() {
        if ( null !== $this->pat ) {
            return $this->pat;
        }

        return '';
    }

    /**
     * Get the authorization header value for the PAT.
     *
     * Using Bearer auth for all token types - GitHub accepts it for both
     * fine-grained (github_pat_) and classic (ghp_) tokens.
     *
     * @return string
     */
    private function get_auth_header() {
        $pat = $this->get_pat();

        if ( empty( $pat ) ) {
            return '';
        }

        // Use Bearer for all token types - GitHub API accepts it universally
        return 'Bearer ' . $pat;
    }

    /**
     * Make a GraphQL request to GitHub.
     *
     * @param string $query     GraphQL query string.
     * @param array  $variables Query variables.
     * @return array|WP_Error
     */
    private function graphql_request( $query, $variables = array() ) {
        $auth_header = $this->get_auth_header();

        if ( empty( $auth_header ) ) {
            return new WP_Error( 'no_auth', 'GraphQL requires authentication.' );
        }

        $body = array( 'query' => $query );
        if ( ! empty( $variables ) ) {
            $body['variables'] = $variables;
        }

        $response = wp_remote_post( self::API_BASE . '/graphql', array(
            'timeout'   => 30,
            'sslverify' => true,
            'headers'   => array(
                'Authorization' => $auth_header,
                'Content-Type'  => 'application/json',
                'User-Agent'    => 'WP-Puller/' . WP_PULLER_VERSION,
            ),
            'body'      => wp_json_encode( $body ),
        ) );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $status_code = wp_remote_retrieve_response_code( $response );
        $data        = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( 200 !== $status_code ) {
            $message = isset( $data['message'] ) ? $data['message'] : 'GraphQL error';
            return new WP_Error( 'graphql_error', $message );
        }

        if ( ! empty( $data['errors'] ) ) {
            return new WP_Error( 'graphql_error', $data['errors'][0]['message'] );
        }

        return $data;
    }

    /**
     * Get the most recently updated branches with commit info.
     *
     * Uses GraphQL when authenticated (single API call) with REST fallback.
     *
     * @param string $owner Repository owner.
     * @param string $repo  Repository name.
     * @param int    $limit Maximum number of branches to return.
     * @return array|WP_Error Array of branch data with commit info.
     */
    public function get_branches_with_info( $owner, $repo, $limit = 10, $configured = '', $deployed = '' ) {
        $cache_key = self::CACHE_PREFIX . 'branches_info_' . md5( $owner . $repo . $limit . $configured . $deployed );
        $cached    = get_transient( $cache_key );

        if ( false !== $cached ) {
            return $cached;
        }

        // Try GraphQL first — paginates through ALL branches (100 per page).
        $branches = $this->get_branches_graphql( $owner, $repo );

        // Fall back to REST API if GraphQL fails (e.g. no PAT for public repo).
        if ( is_wp_error( $branches ) ) {
            $branches = $this->get_branches_rest( $owner, $repo );
        }

        if ( is_wp_error( $branches ) ) {
            return $branches;
        }

        // Sort ALL branches by commit date descending.
        usort( $branches, function ( $a, $b ) {
            return ( $b['timestamp'] ?: 0 ) - ( $a['timestamp'] ?: 0 );
        } );

        // Take the top $limit most recent branches.
        $result       = array_slice( $branches, 0, $limit );
        $result_names = wp_list_pluck( $result, 'name' );

        // Ensure configured and deployed branches always appear in the result.
        $pinned = array_unique( array_filter( array( $configured, $deployed ) ) );

        foreach ( $pinned as $pin_name ) {
            if ( in_array( $pin_name, $result_names, true ) ) {
                continue;
            }
            foreach ( $branches as $b ) {
                if ( $b['name'] === $pin_name ) {
                    $result[] = $b;
                    break;
                }
            }
        }

        set_transient( $cache_key, $result, self::CACHE_DURATION * 2 );

        return $result;
    }

    /**
     * Fetch ALL branches with commit info via GraphQL (paginated, 100 per page).
     *
     * TAG_COMMIT_DATE ordering only works for refs/tags/, not refs/heads/,
     * so we fetch all branches alphabetically and sort by committedDate in PHP.
     *
     * @param string $owner Repository owner.
     * @param string $repo  Repository name.
     * @return array|WP_Error
     */
    private function get_branches_graphql( $owner, $repo ) {
        $query = '
            query($owner: String!, $repo: String!, $count: Int!, $cursor: String) {
                repository(owner: $owner, name: $repo) {
                    refs(refPrefix: "refs/heads/", first: $count, after: $cursor, orderBy: {field: ALPHABETICAL, direction: ASC}) {
                        nodes {
                            name
                            target {
                                ... on Commit {
                                    oid
                                    messageHeadline
                                    committedDate
                                    author {
                                        name
                                        date
                                    }
                                }
                            }
                        }
                        pageInfo {
                            hasNextPage
                            endCursor
                        }
                    }
                }
            }
        ';

        $branches   = array();
        $cursor     = null;
        $max_pages  = 10; // Safety limit: 10 pages × 100 = 1000 branches max.
        $page_count = 0;

        do {
            $variables = array(
                'owner' => $owner,
                'repo'  => $repo,
                'count' => 100,
            );
            if ( null !== $cursor ) {
                $variables['cursor'] = $cursor;
            }

            $result = $this->graphql_request( $query, $variables );

            if ( is_wp_error( $result ) ) {
                // If we already collected some branches, return what we have.
                if ( ! empty( $branches ) ) {
                    break;
                }
                return $result;
            }

            $refs = isset( $result['data']['repository']['refs'] )
                ? $result['data']['repository']['refs']
                : null;

            if ( ! is_array( $refs ) || ! isset( $refs['nodes'] ) ) {
                if ( ! empty( $branches ) ) {
                    break;
                }
                return new WP_Error( 'graphql_parse', 'Unexpected GraphQL response structure.' );
            }

            foreach ( $refs['nodes'] as $node ) {
                $target = isset( $node['target'] ) ? $node['target'] : array();
                $sha    = isset( $target['oid'] ) ? $target['oid'] : '';
                // Prefer committedDate, fall back to author.date.
                $date   = isset( $target['committedDate'] ) ? $target['committedDate'] : '';
                if ( empty( $date ) && isset( $target['author']['date'] ) ) {
                    $date = $target['author']['date'];
                }

                $branches[] = array(
                    'name'      => $node['name'],
                    'sha'       => $sha,
                    'short_sha' => $sha ? substr( $sha, 0, 7 ) : '',
                    'message'   => isset( $target['messageHeadline'] ) ? substr( $target['messageHeadline'], 0, 80 ) : '',
                    'author'    => isset( $target['author']['name'] ) ? $target['author']['name'] : '',
                    'date'      => $date,
                    'timestamp' => ! empty( $date ) ? strtotime( $date ) : 0,
                );
            }

            $has_next = ! empty( $refs['pageInfo']['hasNextPage'] );
            $cursor   = isset( $refs['pageInfo']['endCursor'] ) ? $refs['pageInfo']['endCursor'] : null;
            $page_count++;

        } while ( $has_next && $page_count < $max_pages );

        return $branches;
    }

    /**
     * Fetch ALL branches with commit info via REST API (fallback).
     *
     * Paginates through all branches (100 per page), then fetches commit
     * details for each to get dates. For repos with very many branches,
     * caps commit-detail lookups at 200 to stay within rate limits.
     *
     * @param string $owner Repository owner.
     * @param string $repo  Repository name.
     * @return array|WP_Error
     */
    private function get_branches_rest( $owner, $repo ) {
        // Paginate to get ALL branch names + SHAs.
        $all_branches = array();
        $page         = 1;
        $max_pages    = 5; // 5 pages × 100 = 500 branches max.

        do {
            $response = $this->api_request(
                "/repos/{$owner}/{$repo}/branches?per_page=100&page={$page}"
            );

            if ( is_wp_error( $response ) ) {
                if ( ! empty( $all_branches ) ) {
                    break;
                }
                return $response;
            }

            if ( empty( $response ) || ! is_array( $response ) ) {
                break;
            }

            foreach ( $response as $branch ) {
                $sha = isset( $branch['commit']['sha'] ) ? $branch['commit']['sha'] : '';
                $all_branches[] = array(
                    'name'      => $branch['name'],
                    'sha'       => $sha,
                    'short_sha' => $sha ? substr( $sha, 0, 7 ) : '',
                    'message'   => '',
                    'author'    => '',
                    'date'      => '',
                    'timestamp' => 0,
                );
            }

            $page++;
        } while ( count( $response ) === 100 && $page <= $max_pages );

        // Fetch commit details for each branch to get dates.
        // Cap at 200 to stay within reasonable API usage.
        $lookup_count = min( count( $all_branches ), 200 );

        for ( $i = 0; $i < $lookup_count; $i++ ) {
            $commit = $this->get_latest_commit( $owner, $repo, $all_branches[ $i ]['name'] );
            if ( ! is_wp_error( $commit ) ) {
                $all_branches[ $i ]['message']   = isset( $commit['message'] ) ? substr( $commit['message'], 0, 80 ) : '';
                $all_branches[ $i ]['author']    = isset( $commit['author'] ) ? $commit['author'] : '';
                $all_branches[ $i ]['date']      = isset( $commit['date'] ) ? $commit['date'] : '';
                $all_branches[ $i ]['timestamp'] = ! empty( $commit['date'] ) ? strtotime( $commit['date'] ) : 0;
            }
        }

        return $all_branches;
    }

    /**
     * Compare two refs (branches, tags, or commits).
     *
     * @param string $owner Repository owner.
     * @param string $repo  Repository name.
     * @param string $base  Base ref.
     * @param string $head  Head ref.
     * @return array|WP_Error Comparison data.
     */
    public function compare_commits( $owner, $repo, $base, $head ) {
        $cache_key = self::CACHE_PREFIX . 'compare_' . md5( $owner . $repo . $base . $head );
        $cached    = get_transient( $cache_key );

        if ( false !== $cached ) {
            return $cached;
        }

        $response = $this->api_request(
            sprintf( '/repos/%s/%s/compare/%s...%s', $owner, $repo, $base, $head )
        );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $commits = array();
        if ( isset( $response['commits'] ) ) {
            foreach ( $response['commits'] as $commit ) {
                $commits[] = array(
                    'sha'       => $commit['sha'],
                    'short_sha' => substr( $commit['sha'], 0, 7 ),
                    'message'   => isset( $commit['commit']['message'] ) ? $commit['commit']['message'] : '',
                    'author'    => isset( $commit['commit']['author']['name'] ) ? $commit['commit']['author']['name'] : '',
                    'date'      => isset( $commit['commit']['author']['date'] ) ? $commit['commit']['author']['date'] : '',
                );
            }
        }

        $files = array();
        if ( isset( $response['files'] ) ) {
            foreach ( $response['files'] as $file ) {
                $files[] = array(
                    'filename'  => $file['filename'],
                    'status'    => $file['status'],
                    'additions' => $file['additions'],
                    'deletions' => $file['deletions'],
                    'changes'   => $file['changes'],
                );
            }
        }

        $data = array(
            'status'        => isset( $response['status'] ) ? $response['status'] : '',
            'ahead_by'      => isset( $response['ahead_by'] ) ? $response['ahead_by'] : 0,
            'behind_by'     => isset( $response['behind_by'] ) ? $response['behind_by'] : 0,
            'total_commits'  => isset( $response['total_commits'] ) ? $response['total_commits'] : 0,
            'commits'       => $commits,
            'files'         => $files,
        );

        set_transient( $cache_key, $data, self::CACHE_DURATION * 3 );

        return $data;
    }

    /**
     * Get repository tags.
     *
     * @param string $owner Repository owner.
     * @param string $repo  Repository name.
     * @return array|WP_Error
     */
    public function get_tags( $owner, $repo ) {
        $cache_key = self::CACHE_PREFIX . 'tags_' . md5( $owner . $repo );
        $cached    = get_transient( $cache_key );

        if ( false !== $cached ) {
            return $cached;
        }

        $response = $this->api_request( "/repos/{$owner}/{$repo}/tags" );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $tags = array();
        foreach ( $response as $tag ) {
            $tags[] = array(
                'name'      => $tag['name'],
                'sha'       => isset( $tag['commit']['sha'] ) ? $tag['commit']['sha'] : '',
                'short_sha' => isset( $tag['commit']['sha'] ) ? substr( $tag['commit']['sha'], 0, 7 ) : '',
            );
        }

        set_transient( $cache_key, $tags, self::CACHE_DURATION * 2 );

        return $tags;
    }

    /**
     * Clear all caches.
     */
    public function clear_cache() {
        global $wpdb;

        $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",
                '_transient_' . self::CACHE_PREFIX . '%'
            )
        );

        $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",
                '_transient_timeout_' . self::CACHE_PREFIX . '%'
            )
        );
    }
}
